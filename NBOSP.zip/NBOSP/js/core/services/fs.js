const FS = {
  files: new Map(),             // Kept as a pure native Map for 100% external compatibility
  rootId: null,
  specialFolders: {},
  _childrenByParent: new Map(), // O(1) Fast folder-tree index tracking
  _searchTimeout: null,         // Debounce state holder

  // Internal high-performance helper to index items
  _indexFile(f) {
    if (!f || f.parentId === undefined) return;
    let parentMap = this._childrenByParent.get(f.parentId);
    if (!parentMap) {
      parentMap = new Map();
      this._childrenByParent.set(f.parentId, parentMap);
    }
    parentMap.set(f.id, f);
  },

  // Internal high-performance helper to clear items from index
  _unindexFile(id) {
    const f = this.files.get(id);
    if (!f || f.parentId === undefined) return;
    const parentMap = this._childrenByParent.get(f.parentId);
    if (parentMap) {
      parentMap.delete(id);
      if (parentMap.size === 0) this._childrenByParent.delete(f.parentId);
    }
  },

  async init() {
    try {
      const files = await OS.workers.fs.call('getAllFiles');
      this.files.clear();
      this._childrenByParent.clear();
      if (files && files.length > 0) {
        for (let i = 0; i < files.length; i++) {
          const f = files[i];
          this.files.set(f.id, f);
          this._indexFile(f);
        }
        this.findSpecialFolders();
      } else {
        await this.createDefaultFS();
      }
      this.updateSearchIndex();
    } catch (e) {
      console.warn('[FS] createDefaultFS failed, retrying once:', e);
      if (typeof EventLog !== 'undefined') {
        EventLog.log({ app: 'FS', category: 'filesystem', severity: 'error', message: `FS init failed, retrying: ${e?.message || e}` });
      }
      await this.createDefaultFS();
    }
  },

  findSpecialFolders() {
    for (const [id, f] of this.files) {
      if (f.parentId === null && f.type === 'folder') { 
        this.rootId = id; 
        break; 
      }
    }
    if (this.rootId === null) return;

    const rootChildren = this._childrenByParent.get(this.rootId);
    if (rootChildren) {
      for (const f of rootChildren.values()) {
        const name = f.name.toLowerCase();
        switch (name) {
          case 'desktop': this.specialFolders.desktop = f.id; break;
          case 'documents': this.specialFolders.documents = f.id; break;
          case 'downloads': this.specialFolders.downloads = f.id; break;
          case 'music': this.specialFolders.music = f.id; break;
          case 'pictures': this.specialFolders.pictures = f.id; break;
          case 'videos': this.specialFolders.videos = f.id; break;
          case 'trash': this.specialFolders.trash = f.id; break;
        }
      }
    }
  },

  async createDefaultFS() {
    const now = Date.now();
    const mkNode = (name, type, parentId, content, mime) => ({
      id: generateId(), name, type, parentId,
      content: content || null, blobKey: null,
      size: content ? new Blob([content]).size : 0,
      mimeType: mime || (type === 'folder' ? 'inode/directory' : 'text/plain'),
      created: now, modified: now, accessed: now,
      permissions: { read: true, write: true, execute: false },
      tags: [], sha256: null, icon: null
    });

    const root = mkNode('/', 'folder', null);
    this.rootId = root.id;

    const desktop = mkNode('Desktop', 'folder', root.id);
    const documents = mkNode('Documents', 'folder', root.id);
    const downloads = mkNode('Downloads', 'folder', root.id);
    const music = mkNode('Music', 'folder', root.id);
    const pictures = mkNode('Pictures', 'folder', root.id);
    const videos = mkNode('Videos', 'folder', root.id);
    const trash = mkNode('Trash', 'folder', root.id);
    const screenshots = mkNode('Screenshots', 'folder', pictures.id);

    const allFiles = [root, desktop, documents, downloads, music, pictures, videos, trash, screenshots];

    this.files.clear();
    this._childrenByParent.clear();
    for (let i = 0; i < allFiles.length; i++) {
      const f = allFiles[i];
      this.files.set(f.id, f);
      this._indexFile(f);
    }

    this.specialFolders = {
      desktop: desktop.id, documents: documents.id, downloads: downloads.id,
      music: music.id, pictures: pictures.id, videos: videos.id, trash: trash.id
    };

    await OS.workers.fs.call('putFiles', allFiles);
  },

  listDir(folderId) {
    const parentMap = this._childrenByParent.get(folderId);
    if (!parentMap) return [];
    
    const children = Array.from(parentMap.values());
    return children.sort((a, b) => {
      if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
  },

  // Given a desired name for a new/moved child of parentId, returns a name
  // that doesn't collide with an existing sibling — appending " (1)",
  // " (2)", etc. before the last extension until one is free. Shared by
  // any caller that creates, copies, or moves files/folders (the Files
  // app and the desktop's empty-area "New File"/"New Folder" menu), so
  // none of them silently produce two siblings with the same name.
  // Pass excludeId when checking a node that may already be a sibling of
  // parentId (e.g. moving it within the same folder), so it isn't
  // compared against itself.
  uniqueName(parentId, name, excludeId) {
    const siblings = new Set(
      this.listDir(parentId)
        .filter(f => f.id !== excludeId)
        .map(f => f.name)
    );
    if (!siblings.has(name)) return name;

    const dot = name.lastIndexOf('.');
    // No extension, or a leading dot (e.g. ".gitignore") — treat as no extension.
    const hasExt = dot > 0;
    const base = hasExt ? name.slice(0, dot) : name;
    const ext  = hasExt ? name.slice(dot) : '';

    let i = 1;
    let candidate;
    do {
      candidate = `${base} (${i})${ext}`;
      i++;
    } while (siblings.has(candidate));
    return candidate;
  },

  getPath(id) {
    const parts = [];
    let node = this.files.get(id);
    while (node) {
      if (node.parentId === null) break;
      parts.push(node.name); 
      node = this.files.get(node.parentId);
    }
    return '/' + parts.reverse().join('/');
  },

  getByPath(path) {
    if (path === '/') return this.files.get(this.rootId);
    const parts = path.split('/');
    let current = this.rootId;
    
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (!part) continue;
      
      const parentMap = this._childrenByParent.get(current);
      if (!parentMap) return null;
      
      let found = null;
      for (const c of parentMap.values()) {
        if (c.name === part) {
          found = c;
          break;
        }
      }
      if (!found) return null;
      current = found.id;
    }
    return this.files.get(current);
  },

  async createFile(parentId, name, content, mimeType) {
    const node = {
      id: generateId(), name, type: 'file', parentId,
      content: content || '', blobKey: null,
      size: content ? new Blob([content]).size : 0,
      mimeType: mimeType || 'text/plain',
      created: Date.now(), modified: Date.now(), accessed: Date.now(),
      permissions: { read: true, write: true, execute: false },
      tags: [], sha256: null, icon: null
    };
    this.files.set(node.id, node);
    this._indexFile(node);
    await OS.workers.fs.call('putFiles', [node]);
    this.updateSearchIndex();
    OS.events.emit('fs:created', node);
    if (typeof EventLog !== 'undefined') {
      EventLog.log({ app: 'FS', category: 'filesystem', severity: 'info', message: `Created file ${name}`, data: { id: node.id, parentId, mimeType: node.mimeType } });
    }
    return node;
  },

  async createFolder(parentId, name) {
    const node = {
      id: generateId(), name, type: 'folder', parentId,
      content: null, blobKey: null, size: 0,
      mimeType: 'inode/directory',
      created: Date.now(), modified: Date.now(), accessed: Date.now(),
      permissions: { read: true, write: true, execute: true },
      tags: [], sha256: null, icon: null
    };
    this.files.set(node.id, node);
    this._indexFile(node);
    await OS.workers.fs.call('putFiles', [node]);
    OS.events.emit('fs:created', node);
    if (typeof EventLog !== 'undefined') {
      EventLog.log({ app: 'FS', category: 'filesystem', severity: 'info', message: `Created folder ${name}`, data: { id: node.id, parentId } });
    }
    return node;
  },

  async writeFile(id, content) {
    const node = this.files.get(id);
    if (!node) return null;
    node.content = content;
    node.size = new Blob([content]).size;
    node.modified = Date.now();
    try { node.sha256 = await OS.workers.crypto.call('sha256', content); } catch (e) { }
    await OS.workers.fs.call('putFiles', [node]); 
    this.updateSearchIndex();
    OS.events.emit('fs:updated', node);
    if (typeof EventLog !== 'undefined') {
      EventLog.log({ app: 'FS', category: 'filesystem', severity: 'info', message: `Wrote content to ${node.name}`, data: { id, size: node.size } });
    }
    return node;
  },

  async rename(id, newName) {
    const node = this.files.get(id);
    if (!node) return null;
    const oldName = node.name;
    if (oldName === newName) return node;
    const siblings = this.listDir(node.parentId);
    const collision = siblings.find(f => f.name === newName && f.id !== id);
    if (collision) {
      const err = new Error(`A file or folder named "${newName}" already exists in this location.`);
      err.code = 'EEXIST';
      throw err;
    }
    node.name = newName;
    node.modified = Date.now();
    await OS.workers.fs.call('putFiles', [node]);
    OS.events.emit('fs:updated', node);
    if (typeof EventLog !== 'undefined') {
      EventLog.log({ app: 'FS', category: 'filesystem', severity: 'info', message: `Renamed ${oldName} → ${newName}`, data: { id, oldName, newName } });
    }
    return node;
  },

  async move(id, newParentId) {
    const node = this.files.get(id);
    if (!node) return null;
    this._unindexFile(id);
    node.parentId = newParentId;
    node.modified = Date.now();
    this._indexFile(node);
    await OS.workers.fs.call('putFiles', [node]);
    OS.events.emit('fs:moved', node);
    if (typeof EventLog !== 'undefined') {
      EventLog.log({ app: 'FS', category: 'filesystem', severity: 'info', message: `Moved ${node.name}`, data: { id, newParentId } });
    }
    return node;
  },

  // Recursively copies a file or folder node (and, for folders, every
  // descendant) into destParentId. Shared by any paste implementation
  // (Files app, desktop context menu) so copying a folder always produces
  // a real folder with its contents, not a flattened file.
  //
  // name collisions: only the top-level copy needs a name override —
  // pass one in via `name` if the caller already deduped it with
  // uniqueName(). Recursive calls always target a folder just created
  // fresh, so its children can never already have a same-named sibling.
  async copyNodeInto(node, destParentId, name) {
    const finalName = name ?? node.name;
    if (node.type === 'folder') {
      const newFolder = await this.createFolder(destParentId, finalName);
      for (const child of this.listDir(node.id)) {
        await this.copyNodeInto(child, newFolder.id);
      }
      return newFolder;
    }
    return this.createFile(destParentId, finalName, node.content, node.mimeType);
  },

  // Performs a full cut/copy paste of `clip` ({ type: 'cut'|'copy', fileId })
  // into destParentId, deduping names against existing siblings. Shared by
  // the Files app and the desktop's empty-area context menu so "Paste"
  // behaves identically everywhere instead of each caller reimplementing
  // move/copy semantics. Returns the pasted/moved node, or null if there
  // was nothing valid to paste.
  async pasteInto(clip, destParentId) {
    if (!clip?.fileId) return null;
    const src = this.files.get(clip.fileId);
    if (!src) return null;

    if (clip.type === 'cut') {
      await this.move(src.id, destParentId);
      // Dedupe against the destination's existing children (excluding src
      // itself, in case it's a same-folder move-in-place) so moving into a
      // folder with a same-named item lands as "name (1).ext" instead of
      // silently colliding.
      const finalName = this.uniqueName(destParentId, src.name, src.id);
      if (finalName !== src.name) await this.rename(src.id, finalName);
      return src;
    }

    const finalName = this.uniqueName(destParentId, src.name);
    return this.copyNodeInto(src, destParentId, finalName);
  },

  async deleteToTrash(id) {
    const node = this.files.get(id);
    if (!node) return;
    this._unindexFile(id);
    node._originalParent = node.parentId;
    node.parentId = this.specialFolders.trash;
    node.modified = Date.now();
    this._indexFile(node);
    await OS.workers.fs.call('putFiles', [node]);
    OS.events.emit('fs:deleted', node);
    if (typeof EventLog !== 'undefined') {
      EventLog.log({ app: 'FS', category: 'filesystem', severity: 'warn', message: `Moved ${node.name} to Trash`, data: { id } });
    }
  },

  async permanentDelete(id) {
    const node = this.files.get(id);
    if (!node) return;
    if (node.type === 'folder') {
      const parentMap = this._childrenByParent.get(id);
      if (parentMap) {
        const childIds = Array.from(parentMap.keys());
        for (let i = 0; i < childIds.length; i++) {
          await this.permanentDelete(childIds[i]);
        }
      }
    }
    this._unindexFile(id);
    this.files.delete(id);
    await OS.workers.fs.call('deleteFile', id);
    OS.events.emit('fs:deleted', { id });
    if (typeof EventLog !== 'undefined') {
      EventLog.log({ app: 'FS', category: 'filesystem', severity: 'warn', message: `Permanently deleted ${node.name}`, data: { id, type: node.type } });
    }
  },

  async emptyTrash() {
    const parentMap = this._childrenByParent.get(this.specialFolders.trash);
    if (!parentMap) return;
    const childIds = Array.from(parentMap.keys());
    for (let i = 0; i < childIds.length; i++) {
      await this.permanentDelete(childIds[i]);
    }
  },

  updateSearchIndex() {
    if (this._searchTimeout) clearTimeout(this._searchTimeout);
    
    this._searchTimeout = setTimeout(() => {
      const MAX_CONTENT = 50_000;
      const files = [];
      
      for (const f of this.files.values()) {
        files.push({
          id: f.id,
          name: f.name || '',
          content: typeof f.content === 'string' ? f.content.slice(0, MAX_CONTENT) : ''
        });
      }
      OS.workers.search.call('buildIndex', files).catch(() => { });
    }, 150);
  },

  async search(query) {
    try {
      const files = [];
      for (const f of this.files.values()) files.push(f);
      return await OS.workers.search.call('search', query, files);
    } catch (e) { return []; }
  },

  getMimeIcon(mimeType, name) {
    if (!mimeType) return 'file';
    if (mimeType === 'inode/directory') return 'folder';
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('audio/')) return 'music';
    if (mimeType.startsWith('video/')) return 'file';
    if (mimeType === 'application/pdf') return 'file-text';
    return (name && name.endsWith('.md')) ? 'file-text' : 'file-text';
  }
};

window.FS = FS;