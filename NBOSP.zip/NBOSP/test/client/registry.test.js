import { describe, it, expect, beforeEach, vi } from 'vitest';
import { resetTestStorage } from '../setup.js';

// ── Mock globals for registry ─────────────────────────────────────────────
const mockOS = {
  apps: {},
  openUrl: undefined,
  openMailto: undefined,
  events: { on: vi.fn(), off: vi.fn(), emit: vi.fn() },
};
globalThis.OS = mockOS;
globalThis.window = globalThis;

if (typeof globalThis.document === 'undefined') {
  globalThis.document = {
    createElement: vi.fn((tag) => ({
      tagName: tag.toUpperCase(),
      style: {},
      setAttribute: vi.fn(),
      getAttribute: vi.fn(),
      removeAttribute: vi.fn(),
      appendChild: vi.fn(),
      removeChild: vi.fn(),
      addEventListener: vi.fn(),
      textContent: '',
      innerHTML: '',
      classList: { add: vi.fn(), remove: vi.fn(), toggle: vi.fn(), contains: vi.fn(() => false) },
      dataset: {},
      children: [],
      parentNode: null,
      closest: vi.fn((sel) => {
        if (sel === 'a[href]') return null;
        return null;
      }),
    })),
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    readyState: 'complete',
    querySelector: vi.fn(() => null),
    querySelectorAll: vi.fn(() => []),
    body: { appendChild: vi.fn() },
    documentElement: { style: {}, classList: {} },
  };
}

// APP_REGISTRY is used by registry.js (not app-registry.js)
if (!Array.isArray(window.APP_REGISTRY)) {
  window.APP_REGISTRY = [];
}

describe('AppRegistry (js/platform/core/app-registry.js)', () => {
  beforeEach(() => {
    resetTestStorage();
    vi.resetModules();
    mockOS.apps = {};
  });

  it('registers an app and populates OS.apps', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    const config = { id: 'test-app', name: 'Test', icon: 'box', version: '1.0.0', entry: 'index.html' };
    const result = mod.registerApp(config);
    expect(result).toBeDefined();
    expect(result.id).toBe('test-app');
    expect(result.name).toBe('Test');
    expect(mockOS.apps['test-app']).toBeDefined();
    expect(mockOS.apps['test-app'].name).toBe('Test');
  });

  it('fills default fields when omitted', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    const result = mod.registerApp({ id: 'minimal', name: 'Minimal' });
    expect(result.version).toBe('1.0.0');
    expect(result.type).toBe('webapp');
    expect(result.permissions).toEqual([]);
    expect(result.defaultSize).toEqual([800, 600]);
  });

  it('returns existing app without re-registering', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    mod.registerApp({ id: 'dup', name: 'First' });
    const second = mod.registerApp({ id: 'dup', name: 'Second' });
    expect(second.name).toBe('First');
  });

  it('throws when id or name is missing', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    expect(() => mod.registerApp({})).toThrow('[AppRegistry] App must have id and name');
    expect(() => mod.registerApp({ id: 'x' })).toThrow('[AppRegistry] App must have id and name');
  });

  it('rejects reserved IDs unless verified is true', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    expect(() => mod.registerApp({ id: 'com.nbosp.settings', name: 'Settings' })).toThrow(/reserved/);
    const result = mod.registerApp({ id: 'com.nbosp.settings', name: 'Settings', verified: true });
    expect(result.id).toBe('com.nbosp.settings');
  });

  it('strips unknown permissions with a warning', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    const spy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    mod.registerApp({ id: 'perm-test', name: 'PT', permissions: ['vfs:read', 'evil:inject'] });
    expect(spy).toHaveBeenCalled();
    const app = mod.getApp('perm-test');
    expect(app.permissions).not.toContain('evil:inject');
    expect(app.permissions).toContain('vfs:read');
    spy.mockRestore();
  });

  it('unregisters an app and cleans up OS.apps', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    mod.registerApp({ id: 'to-remove', name: 'Remove' });
    expect(mod.unregisterApp('to-remove')).toBe(true);
    expect(mod.getApp('to-remove')).toBeNull();
    expect(mockOS.apps['to-remove']).toBeUndefined();
    expect(mod.unregisterApp('to-remove')).toBe(false);
  });

  it('fires onInstall and onUninstall hooks', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    const installed = [];
    const uninstalled = [];
    mod.onInstall((app) => installed.push(app.id));
    mod.onUninstall((app) => uninstalled.push(app.id));
    mod.registerApp({ id: 'hook-app', name: 'Hook' });
    expect(installed).toContain('hook-app');
    mod.unregisterApp('hook-app');
    expect(uninstalled).toContain('hook-app');
  });

  it('getStats returns correct counts', () => {
    vi.resetModules();
    localStorage.clear();
    const mod = require('../../js/platform/core/app-registry.js');
    for (const app of mod.getAllApps()) mod.unregisterApp(app.id);
    mod.registerApp({ id: 'a1', name: 'A1', categories: ['productivity'] });
    mod.registerApp({ id: 'a2', name: 'A2', categories: ['productivity', 'social'] });
    const stats = mod.getStats();
    expect(stats.totalApps).toBe(2);
    expect(stats.byCategory.productivity).toBe(2);
    expect(stats.totalLaunches).toBe(0);
  });

  it('checkPermissions returns true when APM is absent', () => {
    const prev = globalThis.AppPermissionManager;
    globalThis.AppPermissionManager = undefined;
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    const app = mod.registerApp({ id: 'cp-app', name: 'CPA', permissions: ['vfs:read'] });
    expect(mod.checkPermissions(app)).toBe(true);
    globalThis.AppPermissionManager = prev;
  });

  it('updateApp patches fields on an installed app', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    mod.registerApp({ id: 'patch-me', name: 'Patch' });
    expect(mod.updateApp('patch-me', { version: '2.0.0' })).toBe(true);
    expect(mod.getApp('patch-me').version).toBe('2.0.0');
    expect(mod.updateApp('nonexistent', {})).toBe(false);
  });

  it('getAppsByCategory filters correctly', () => {
    vi.resetModules();
    const mod = require('../../js/platform/core/app-registry.js');
    mod.registerApp({ id: 'cat1', name: 'C1', categories: ['dev'] });
    mod.registerApp({ id: 'cat2', name: 'C2', categories: ['social'] });
    const devApps = mod.getAppsByCategory('dev');
    expect(devApps).toHaveLength(1);
    expect(devApps[0].id).toBe('cat1');
  });
});

describe('registry.js — OS.openUrl, OS.openMailto, and WebAppManager', () => {
  beforeEach(() => {
    resetTestStorage();
    vi.resetModules();
    mockOS.apps = {};
    window.APP_REGISTRY = [];
  });

  it('registerApp adds to OS.apps and APP_REGISTRY', () => {
    vi.resetModules();
    const mod = require('../../js/core/services/registry.js');
    const cfg = { id: 'web-app', name: 'Web App', url: 'https://example.com' };
    if (typeof globalThis.registerApp === 'function') {
      globalThis.registerApp(cfg);
    }
    expect(mockOS.apps['web-app']).toEqual(cfg);
    expect(window.APP_REGISTRY).toContain(cfg);
  });

  it('OS.openUrl opens http/https links in the browser app', () => {
    vi.resetModules();
    require('../../js/core/services/registry.js');
    const createWindow = vi.fn(() => ({ id: 'win1' }));
    globalThis.WM = { createWindow };
    globalThis.nw = undefined;
    mockOS.openUrl('https://example.com/page');
    expect(createWindow).toHaveBeenCalledWith('browser', { url: 'https://example.com/page' });
  });

  it('OS.openUrl blocks javascript: and data: URLs', () => {
    vi.resetModules();
    require('../../js/core/services/registry.js');
    const createWindow = vi.fn();
    globalThis.WM = { createWindow };
    mockOS.openUrl('javascript:alert(1)');
    mockOS.openUrl('data:text/html,<script>alert(1)</script>');
    expect(createWindow).not.toHaveBeenCalled();
  });

  it('OS.openMailto parses a full mailto URI', () => {
    vi.resetModules();
    require('../../js/core/services/registry.js');
    const createWindow = vi.fn(() => ({ id: 'win1' }));
    globalThis.WM = { createWindow };
    mockOS.openMailto('mailto:alice@example.com?subject=Hello&body=World&cc=bob@example.com&bcc=carol@example.com');
    expect(createWindow).toHaveBeenCalledWith('nbosp-email', {
      compose: {
        to: 'alice@example.com',
        subject: 'Hello',
        body: 'World',
        cc: 'bob@example.com',
        bcc: 'carol@example.com',
      },
    });
  });

  it('OS.openMailto handles a bare address', () => {
    vi.resetModules();
    require('../../js/core/services/registry.js');
    const createWindow = vi.fn(() => ({ id: 'win1' }));
    globalThis.WM = { createWindow };
    mockOS.openMailto('mailto:alice@example.com');
    expect(createWindow).toHaveBeenCalledWith('nbosp-email', {
      compose: { to: 'alice@example.com', subject: '', body: '', cc: '', bcc: '' },
    });
  });

  it('OS.openMailto ignores empty URLs', () => {
    vi.resetModules();
    require('../../js/core/services/registry.js');
    const createWindow = vi.fn();
    globalThis.WM = { createWindow };
    mockOS.openMailto('');
    mockOS.openMailto(null);
    expect(createWindow).not.toHaveBeenCalled();
  });
});

describe('WebAppManager (js/core/services/registry.js)', () => {
  beforeEach(() => {
    resetTestStorage();
    vi.resetModules();
    localStorage.removeItem('nova_webapps');
  });

  it('addApp persists to localStorage and returns an app object', () => {
    vi.resetModules();
    const mod = require('../../js/core/services/registry.js');
    const app = window.WebAppManager.addApp({ name: 'Test WA', url: 'https://wa.test' });
    expect(app.id).toBeDefined();
    expect(app.name).toBe('Test WA');
    expect(app.url).toBe('https://wa.test');
    expect(app.launchCount).toBe(0);
    const stored = JSON.parse(localStorage.getItem('nova_webapps'));
    expect(stored.some(a => a.id === app.id)).toBe(true);
  });

  it('getApp retrieves by id', () => {
    vi.resetModules();
    const mod = require('../../js/core/services/registry.js');
    const created = window.WebAppManager.addApp({ name: 'Find Me', url: 'https://find.me' });
    const found = window.WebAppManager.getApp(created.id);
    expect(found).not.toBeNull();
    expect(found.name).toBe('Find Me');
  });

  it('getApp returns null for missing id', () => {
    vi.resetModules();
    const mod = require('../../js/core/services/registry.js');
    expect(window.WebAppManager.getApp('does-not-exist')).toBeNull();
  });

  it('removeApp deletes the app from storage', () => {
    vi.resetModules();
    const mod = require('../../js/core/services/registry.js');
    const created = window.WebAppManager.addApp({ name: 'Delete Me', url: 'https://del.me' });
    window.WebAppManager.removeApp(created.id);
    expect(window.WebAppManager.getApp(created.id)).toBeNull();
  });

  it('launchApp increments launchCount and updates lastUsed', () => {
    vi.resetModules();
    const mod = require('../../js/core/services/registry.js');
    const created = window.WebAppManager.addApp({ name: 'Launch Me', url: 'https://launch.me' });
    window.WebAppManager.launchApp(created.id);
    const updated = window.WebAppManager.getApp(created.id);
    expect(updated.launchCount).toBe(1);
    expect(updated.lastUsed).toBeDefined();
  });
});