(() => {
  const key='dirazcoder.kanban.v1',root=document.querySelector('#app'),states=['Backlog','In progress','Done'];
  const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  let tasks;try{tasks=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(tasks))tasks=[];}catch{tasks=[];}
  const save=()=>localStorage.setItem(key,JSON.stringify(tasks));
  const render=()=>{
    root.replaceChildren();const head=node('header');head.append(node('h1','Kanban Board'),node('p','Move work forward one card at a time.'));
    const form=node('form',null,'panel row');const title=node('input');title.placeholder='New task';title.required=true;title.maxLength=120;const label=node('input');label.placeholder='Project or label';label.maxLength=32;const add=node('button','Add to backlog','primary');add.type='submit';form.append(title,label,add);
    form.onsubmit=e=>{e.preventDefault();tasks.push({id:crypto.randomUUID(),title:title.value.trim(),label:label.value.trim(),status:0,created:Date.now()});save();render();};
    const board=node('div',null,'board');for(let column=0;column<states.length;column++){const section=node('section',null,'column');section.append(node('h2',`${states[column]} · ${tasks.filter(t=>t.status===column).length}`));
      for(const task of tasks.filter(t=>t.status===column)){const card=node('article',null,'task');card.append(node('strong',task.title));if(task.label)card.append(node('span',task.label,'tag'));const actions=node('div',null,'row');
        if(column>0){const back=node('button','←');back.setAttribute('aria-label','Move to previous column');back.onclick=()=>{task.status--;save();render();};actions.append(back);}
        if(column<2){const next=node('button',column===1?'Complete ✓':'Move →','primary');next.onclick=()=>{task.status++;save();render();};actions.append(next);}
        const remove=node('button','Delete');remove.onclick=()=>{tasks=tasks.filter(t=>t.id!==task.id);save();render();};actions.append(remove);card.append(actions);section.append(card);}
      if(!tasks.some(t=>t.status===column))section.append(node('p','No cards yet.','muted'));board.append(section);}
    root.append(head,form,board);
  };
  render();
})();
