(() => {
  const key = 'dirazcoder.planner.v1', root = document.querySelector('#app');
  const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const id = () => crypto.randomUUID();
  const node = (tag, text, cls) => { const n=document.createElement(tag); if(text!=null)n.textContent=text; if(cls)n.className=cls; return n; };
  let tasks; try { tasks=JSON.parse(localStorage.getItem(key)||'[]'); if(!Array.isArray(tasks))tasks=[]; } catch { tasks=[]; }
  const save=()=>localStorage.setItem(key,JSON.stringify(tasks));
  const render=()=>{
    root.replaceChildren(); const head=node('header'); head.append(node('h1','Daily Planner'),node('p',new Date(`${today()}T12:00:00`).toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric',year:'numeric'})));
    const form=node('form',null,'panel row'); const title=node('input'); title.placeholder='What needs doing?'; title.required=true; title.maxLength=120;
    const time=node('input'); time.type='time'; time.setAttribute('aria-label','Time');
    const priority=node('select'); for(const value of ['Normal','High','Low']){const o=node('option',value);priority.append(o);}
    const add=node('button','Add task','primary'); add.type='submit'; form.append(title,time,priority,add);
    form.onsubmit=e=>{e.preventDefault();tasks.unshift({id:id(),title:title.value.trim(),date:today(),time:time.value,priority:priority.value,done:false});save();render();};
    const todayTasks=tasks.filter(t=>t.date===today()); const stats=node('div',null,'stats');
    for(const [number,label] of [[todayTasks.length,'planned today'],[todayTasks.filter(t=>t.done).length,'completed'],[todayTasks.filter(t=>!t.done).length,'remaining']]){const s=node('div',null,'stat');s.append(node('strong',String(number)),node('span',label));stats.append(s);}
    const list=node('section',null,'list');
    for(const task of todayTasks){const item=node('article',null,'item');const check=node('input');check.type='checkbox';check.checked=task.done;check.setAttribute('aria-label',`Complete ${task.title}`);check.onchange=()=>{task.done=check.checked;save();render();};
      const text=node('div');const h=node('strong',task.title);if(task.done)h.style.textDecoration='line-through';text.append(h,node('p',`${task.time||'Any time'} · ${task.priority} priority`,'muted'));
      const remove=node('button','Remove');remove.onclick=()=>{tasks=tasks.filter(t=>t.id!==task.id);save();render();};item.append(check,text,remove);list.append(item);}
    if(!todayTasks.length)list.append(node('p','Nothing planned yet. Add one small, clear task to get started.','muted'));
    const upcoming=tasks.filter(t=>t.date>today()).sort((a,b)=>a.date.localeCompare(b.date));
    root.append(head,form,stats,node('h2','Today'),list);
    if(upcoming.length){const section=node('section',null,'list');for(const task of upcoming){const row=node('article',null,'item');row.append(node('strong',task.title),node('span',`${task.date}${task.time?` · ${task.time}`:''}`,'muted'));section.append(row);}root.append(node('h2','Coming up'),section);}
  };
  render();
})();
