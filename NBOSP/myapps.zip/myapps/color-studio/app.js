(() => {
  const key='dirazcoder.colors.v1',root=document.querySelector('#app');
  const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  let palettes;try{palettes=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(palettes))palettes=[];}catch{palettes=[];}
  const save=()=>localStorage.setItem(key,JSON.stringify(palettes));
  const hex=h=>{const n=parseInt(h.slice(1),16);return[(n>>16)&255,(n>>8)&255,n&255];};
  const toHex=(r,g,b)=>`#${[r,g,b].map(v=>Math.round(v).toString(16).padStart(2,'0')).join('')}`;
  const contrast=(color)=>{const lin=hex(color).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;});const l=.2126*lin[0]+.7152*lin[1]+.0722*lin[2];return ((1.05)/(l+.05)).toFixed(2);};
  const generate=base=>{const [r,g,b]=hex(base),max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min;let h=0;if(d){if(max===r)h=((g-b)/d)%6;else if(max===g)h=(b-r)/d+2;else h=(r-g)/d+4;h=Math.round(h*60);if(h<0)h+=360;}const l=(max+min)/510,s=d?d/(1-Math.abs(2*l-1)):0;return[-36,-18,0,18,36].map(delta=>{const x=((h+delta+360)%360)/60,c=(1-Math.abs(2*l-1))*s,m=l-c/2,z=c*(1-Math.abs(x%2-1));let rgb=x<1?[c,z,0]:x<2?[z,c,0]:x<3?[0,c,z]:x<4?[0,z,c]:x<5?[z,0,c]:[c,0,z];return toHex(...rgb.map(v=>(v+m)*255));});};
  const render=()=>{
    root.replaceChildren();const head=node('header');head.append(node('h1','Color Studio'),node('p','Build a palette, copy exact values, and check text contrast.'));
    const panel=node('section',null,'panel grid'),row=node('div',null,'row');const picker=node('input');picker.type='color';picker.value='#65d6ad';const label=node('span','Choose a seed color');const saveButton=node('button','Save palette','primary');row.append(picker,label,saveButton);const swatches=node('div',null,'swatches');let current=generate(picker.value);
    const draw=()=>{current=generate(picker.value);swatches.replaceChildren();for(const color of current){const card=node('button',color,'swatch');card.style.background=color;card.style.color=contrast(color)>4.5?'#10151f':'#fff';card.title=`Copy ${color} · contrast ${contrast(color)}:1`;card.onclick=async()=>{await navigator.clipboard?.writeText(color);label.textContent=`Copied ${color} · ${contrast(color)}:1 contrast`;};swatches.append(card);}};
    picker.oninput=draw;saveButton.onclick=()=>{palettes.unshift({id:crypto.randomUUID(),colors:[...current],date:new Date().toLocaleDateString()});save();render();};panel.append(row,swatches);
    const saved=node('section',null,'list');for(const palette of palettes){const item=node('article',null,'item'),colors=node('div',null,'swatches');for(const color of palette.colors){const chip=node('button',color,'swatch');chip.style.background=color;chip.onclick=()=>navigator.clipboard?.writeText(color);colors.append(chip);}const remove=node('button','Delete');remove.onclick=()=>{palettes=palettes.filter(p=>p.id!==palette.id);save();render();};item.append(node('div',`${palette.date} · ${palette.colors.join(' ')}`),colors,remove);saved.append(item);}if(!palettes.length)saved.append(node('p','Saved palettes appear here.','muted'));
    root.append(head,panel,node('h2','Saved palettes'),saved);draw();
  };
  render();
})();
