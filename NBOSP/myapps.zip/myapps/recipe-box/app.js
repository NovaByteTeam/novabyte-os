(() => {
  const key='dirazcoder.recipes.v1',root=document.querySelector('#app');
  const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  let recipes;try{recipes=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(recipes))recipes=[];}catch{recipes=[];}
  const save=()=>localStorage.setItem(key,JSON.stringify(recipes));
  const render=()=>{
    root.replaceChildren();const head=node('header');head.append(node('h1','Recipe Box'),node('p','Your kitchen favorites, organized and ready when you are.'));
    const form=node('form',null,'panel grid');const row=node('div',null,'row');const name=node('input');name.placeholder='Recipe name';name.required=true;name.maxLength=100;
    const category=node('input');category.placeholder='Category (e.g. Dinner)';category.maxLength=32;const minutes=node('input');minutes.type='number';minutes.min='1';minutes.placeholder='Minutes';minutes.title='Prep time in minutes';const add=node('button','Save recipe','primary');add.type='submit';row.append(name,category,minutes);
    const ingredients=node('textarea');ingredients.placeholder='Ingredients — one per line';ingredients.required=true;
    const instructions=node('textarea');instructions.placeholder='Instructions';instructions.required=true;form.append(row,ingredients,instructions,add);
    form.onsubmit=e=>{e.preventDefault();recipes.unshift({id:crypto.randomUUID(),name:name.value.trim(),category:category.value.trim()||'Uncategorized',minutes:Number(minutes.value)||0,ingredients:ingredients.value.split('\n').map(x=>x.trim()).filter(Boolean),instructions:instructions.value.trim(),favorite:false});save();render();};
    const search=node('input');search.placeholder='Search recipes and ingredients…';
    const list=node('section',null,'list');const fill=()=>{
      list.replaceChildren();const q=search.value.trim().toLowerCase();
      const filtered=recipes.filter(r=>`${r.name} ${r.category} ${r.ingredients.join(' ')}`.toLowerCase().includes(q));
      for(const recipe of filtered){const item=node('article',null,'item'),copy=node('div');copy.append(node('strong',`${recipe.favorite?'★ ':''}${recipe.name}`),node('p',`${recipe.category} · ${recipe.minutes?`${recipe.minutes} min`:'time not set'} · ${recipe.ingredients.length} ingredients`,'muted'));
        const details=node('details');details.append(node('summary','Open recipe'));const ing=node('p',`Ingredients: ${recipe.ingredients.join(', ')}`);const steps=node('p',recipe.instructions);details.append(ing,steps);copy.append(details);
        const actions=node('div',null,'row');const fav=node('button',recipe.favorite?'★ Saved':'☆ Favorite');fav.onclick=()=>{recipe.favorite=!recipe.favorite;save();fill();};const remove=node('button','Delete');remove.onclick=()=>{recipes=recipes.filter(r=>r.id!==recipe.id);save();fill();};actions.append(fav,remove);item.append(copy,actions);list.append(item);}
      if(!filtered.length)list.append(node('p',q?'No recipes match that search.':'Your recipe collection is ready for its first entry.','muted'));
    };
    search.oninput=fill;fill();root.append(head,form,search,list);
  };
  render();
})();
