(() => {
  const key='dirazcoder.world-clock.v1',root=document.querySelector('#app');
  const cities=[['UTC','UTC'],['New York','America/New_York'],['Los Angeles','America/Los_Angeles'],['Chicago','America/Chicago'],['London','Europe/London'],['Paris','Europe/Paris'],['Dubai','Asia/Dubai'],['Mumbai','Asia/Kolkata'],['Singapore','Asia/Singapore'],['Tokyo','Asia/Tokyo'],['Sydney','Australia/Sydney'],['Auckland','Pacific/Auckland']];
  const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  let zones;try{zones=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(zones))zones=[];}catch{zones=[];}
  if(!zones.length)zones=[{name:'London',zone:'Europe/London'},{name:'New York',zone:'America/New_York'},{name:'Tokyo',zone:'Asia/Tokyo'}];
  const save=()=>localStorage.setItem(key,JSON.stringify(zones));
  const render=()=>{
    root.replaceChildren();const head=node('header');head.append(node('h1','World Clock'),node('p','Your people and places, in the right time.'));
    const form=node('form',null,'panel row'),select=node('select');select.setAttribute('aria-label','Choose a city');for(const [name,zone] of cities){const opt=node('option',`${name} · ${zone}`);opt.value=zone;opt.dataset.name=name;select.append(opt);}
    const add=node('button','Add clock','primary');add.type='submit';form.append(select,add);
    form.onsubmit=e=>{e.preventDefault();const choice=cities.find(x=>x[1]===select.value);if(choice&&!zones.some(z=>z.zone===choice[1])){zones.push({name:choice[0],zone:choice[1]});save();paint();}};
    const list=node('section',null,'list');const paint=()=>{list.replaceChildren();for(const city of zones){const item=node('article',null,'item'),copy=node('div');copy.append(node('strong',city.name),node('p','…','clock-time'));const remove=node('button','Remove');remove.onclick=()=>{zones=zones.filter(z=>z.zone!==city.zone);save();paint();};item.append(copy,remove);list.append(item);}update();};
    const update=()=>{for(const [i,city] of zones.entries()){const label=list.children[i]?.querySelector('.clock-time');if(label)label.textContent=new Intl.DateTimeFormat(undefined,{timeZone:city.zone,weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit',second:'2-digit',hour12:true}).format(new Date());}};
    root.append(head,form,list);paint();setInterval(update,1000);
  };
  render();
})();
