(() => {
  const key='dirazcoder.budget.v1',root=document.querySelector('#app');
  const day=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
  const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  let entries;try{entries=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(entries))entries=[];}catch{entries=[];}
  const save=()=>localStorage.setItem(key,JSON.stringify(entries));
  const render=()=>{
    root.replaceChildren();const head=node('header');head.append(node('h1','Budget Tracker'),node('p','Know where your money goes. This ledger stays on this device.'));
    const form=node('form',null,'panel grid');const row=node('div',null,'row');const title=node('input');title.placeholder='Description';title.required=true;title.maxLength=80;
    const amount=node('input');amount.type='number';amount.min='0.01';amount.step='0.01';amount.placeholder='Amount';amount.required=true;
    const type=node('select');for(const v of ['Expense','Income'])type.append(node('option',v));
    const category=node('select');for(const v of ['General','Food','Home','Transport','Health','Shopping','Bills','Salary','Other'])category.append(node('option',v));
    const add=node('button','Add transaction','primary');add.type='submit';row.append(title,amount,type,category,add);form.append(row);
    form.onsubmit=e=>{e.preventDefault();entries.unshift({id:crypto.randomUUID(),title:title.value.trim(),amount:Number(amount.value),type:type.value,category:category.value,date:day()});save();render();};
    const month=day().slice(0,7),current=entries.filter(x=>x.date.startsWith(month)),income=current.filter(x=>x.type==='Income').reduce((a,x)=>a+x.amount,0),spent=current.filter(x=>x.type==='Expense').reduce((a,x)=>a+x.amount,0);
    const stats=node('div',null,'stats');for(const [value,label] of [[`$${income.toFixed(2)}`,'income this month'],[`$${spent.toFixed(2)}`,'spent this month'],[`$${(income-spent).toFixed(2)}`,'net this month']]){const s=node('div',null,'stat');s.append(node('strong',value),node('span',label));stats.append(s);}
    const list=node('section',null,'list');for(const entry of entries){const item=node('article',null,'item'),copy=node('div');copy.append(node('strong',entry.title),node('p',`${entry.date} · ${entry.category}`,'muted'));const amountText=node('strong',`${entry.type==='Income'?'+':'−'}$${entry.amount.toFixed(2)}`);amountText.className=entry.type==='Income'?'accent':'';
      const remove=node('button','Remove');remove.onclick=()=>{entries=entries.filter(x=>x.id!==entry.id);save();render();};item.append(copy,amountText,remove);list.append(item);}
    if(!entries.length)list.append(node('p','Your transactions will appear here.','muted'));
    root.append(head,form,stats,node('h2','Transactions'),list);
  };
  render();
})();
