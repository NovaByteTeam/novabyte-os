(() => {
  const key = 'dirazcoder.focus.v1';
  const root = document.querySelector('#app');
  const state = { mode: 'Focus', seconds: 25 * 60, running: false, completed: 0, length: 25 };
  const read = () => { try { return JSON.parse(localStorage.getItem(key) || '{}'); } catch { return {}; } };
  Object.assign(state, read());
  let interval;
  const node = (tag, text, cls) => { const n = document.createElement(tag); if (text != null) n.textContent = text; if (cls) n.className = cls; return n; };
  const save = () => localStorage.setItem(key, JSON.stringify({ mode: state.mode, seconds: state.seconds, completed: state.completed, length: state.length }));
  const render = () => {
    root.replaceChildren();
    const header = node('header'); header.append(node('h1', 'Focus Timer'), node('p', 'One task. One session. Make the next 25 minutes count.'));
    const panel = node('section', null, 'panel grid');
    const modes = node('div', null, 'row');
    for (const mode of ['Focus', 'Short break', 'Long break']) {
      const b = node('button', mode, mode === state.mode ? 'primary' : '');
      b.onclick = () => { state.mode = mode; state.seconds = (mode === 'Focus' ? state.length : mode === 'Short break' ? 5 : 15) * 60; state.running = false; clearInterval(interval); save(); render(); };
      modes.append(b);
    }
    const clock = node('div', `${String(Math.floor(state.seconds / 60)).padStart(2, '0')}:${String(state.seconds % 60).padStart(2, '0')}`, 'timer');
    clock.setAttribute('role', 'timer');
    const desc = node('p', state.mode === 'Focus' ? 'Protect your attention. Take a short break when the session ends.' : 'Step away from your screen and reset.');
    const controls = node('div', null, 'row');
    const toggle = node('button', state.running ? 'Pause' : 'Start', 'primary');
    toggle.onclick = () => {
      state.running = !state.running; clearInterval(interval);
      if (state.running) interval = setInterval(() => {
        if (state.seconds > 0) state.seconds--;
        else { state.running = false; clearInterval(interval); if (state.mode === 'Focus') state.completed++; }
        save(); render();
      }, 1000);
      render();
    };
    const reset = node('button', 'Reset');
    reset.onclick = () => { state.running = false; clearInterval(interval); state.seconds = (state.mode === 'Focus' ? state.length : state.mode === 'Short break' ? 5 : 15) * 60; save(); render(); };
    controls.append(toggle, reset);
    const settings = node('label', 'Focus length (minutes)', 'muted');
    const input = node('input'); input.type = 'number'; input.min = '5'; input.max = '90'; input.value = state.length;
    input.onchange = () => { state.length = Math.max(5, Math.min(90, Number(input.value) || 25)); if (state.mode === 'Focus' && !state.running) state.seconds = state.length * 60; save(); render(); };
    settings.append(input);
    const stats = node('div', null, 'stats'); const stat = node('div', null, 'stat'); stat.append(node('strong', String(state.completed)), node('span', 'focus sessions completed')); stats.append(stat);
    panel.append(modes, clock, desc, controls, settings, stats); root.append(header, panel);
  };
  render();
})();
