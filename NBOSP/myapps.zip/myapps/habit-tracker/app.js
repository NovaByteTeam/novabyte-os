(() => {
  const key='dirazcoder.habits.v1',root=document.querySelector('#app');
  const dateKey=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
  const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  let habits;try{habits=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(habits))habits=[];}catch{habits=[];}
  const save=()=>localStorage.setItem(key,JSON.stringify(habits));
  const streak=habit=>{let n=0,d=new Date();for(let i=0;i<366;i++){const k=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;if(!habit.days?.includes(k))break;n++;d.setDate(d.getDate()-1);}return n;};
  const render=()=>{
    root.replaceChildren();const head=node('header');head.append(node('h1','Habit Tracker'),node('p','Small actions, repeated often, become part of who you are.'));
    const form=node('form',null,'panel row');const name=node('input');name.placeholder='Add a habit (e.g. Read 10 pages)';name.required=true;name.maxLength=80;const add=node('button','Create habit','primary');add.type='submit';form.append(name,add);
    form.onsubmit=e=>{e.preventDefault();habits.push({id:crypto.randomUUID(),name:name.value.trim(),days:[]});save();render();};
    const today=dateKey(),done=habits.filter(h=>h.days?.includes(today)).length;const stats=node('div',null,'stats');
    for(const [value,label] of [[habits.length,'active habits'],[done,'done today'],[habits.length-done,'left today']]){const s=node('div',null,'stat');s.append(node('strong',String(value)),node('span',label));stats.append(s);}
    const list=node('section',null,'list');
    for(const habit of habits){const item=node('article',null,'item');const copy=node('div');copy.append(node('strong',habit.name),node('p',`${streak(habit)} day streak · ${habit.days?.length||0} total check-ins`,'muted'));
      const check=node('button',habit.days?.includes(today)?'Done today ✓':'Mark done');check.className=habit.days?.includes(today)?'primary':'';check.onclick=()=>{habit.days||=[];if(habit.days.includes(today))habit.days=habit.days.filter(d=>d!==today);else habit.days.push(today);save();render();};
      const remove=node('button','×');remove.setAttribute('aria-label',`Delete ${habit.name}`);remove.onclick=()=>{habits=habits.filter(h=>h.id!==habit.id);save();render();};item.append(copy,check,remove);list.append(item);}
    if(!habits.length)list.append(node('p','Create a habit to start your first streak.','muted'));
    root.append(head,form,stats,node('h2','Your habits'),list);
  };
  render();
})();
