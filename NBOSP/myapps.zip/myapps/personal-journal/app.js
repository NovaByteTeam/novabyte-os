(() => {
  const key='dirazcoder.journal.v1',root=document.querySelector('#app');
  const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
  const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  let entries;try{entries=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(entries))entries=[];}catch{entries=[];}
  const save=()=>localStorage.setItem(key,JSON.stringify(entries));
  const render=()=>{
    root.replaceChildren();const head=node('header');head.append(node('h1','Personal Journal'),node('p','A private space for your thoughts. Entries stay in this browser on this device.'));
    const form=node('form',null,'panel grid');const row=node('div',null,'row');const date=node('input');date.type='date';date.value=today();const title=node('input');title.placeholder='Give today a title';title.maxLength=100;title.required=true;
    const mood=node('select');for(const value of ['🙂 Good','😌 Calm','⚡ Energized','🌧️ Difficult','🤔 Reflective'])mood.append(node('option',value));
    const body=node('textarea');body.placeholder='What is on your mind?';body.required=true;body.maxLength=12000;const saveButton=node('button','Save entry','primary');saveButton.type='submit';row.append(date,title,mood);form.append(row,body,saveButton);
    form.onsubmit=e=>{e.preventDefault();const entry={id:crypto.randomUUID(),date:date.value,title:title.value.trim(),mood:mood.value,body:body.value.trim()};const index=entries.findIndex(x=>x.date===entry.date);if(index>=0)entries[index]=entry;else entries.unshift(entry);save();render();};
    const search=node('input');search.placeholder='Search your journal…';const list=node('section',null,'list');const draw=()=>{list.replaceChildren();const q=search.value.toLowerCase();const filtered=entries.filter(x=>`${x.title} ${x.body} ${x.mood}`.toLowerCase().includes(q));for(const entry of filtered){const item=node('article',null,'item'),copy=node('div');copy.append(node('strong',entry.title),node('p',`${entry.date} · ${entry.mood}`,'muted'),node('p',entry.body.length>220?`${entry.body.slice(0,220)}…`:entry.body));
      const actions=node('div',null,'row');const edit=node('button','Edit');edit.onclick=()=>{date.value=entry.date;title.value=entry.title;mood.value=entry.mood;body.value=entry.body;form.scrollIntoView({behavior:'smooth'});};const remove=node('button','Delete');remove.onclick=()=>{entries=entries.filter(x=>x.id!==entry.id);save();draw();};actions.append(edit,remove);item.append(copy,actions);list.append(item);}
      if(!filtered.length)list.append(node('p',q?'No entries match your search.':'Your saved entries will show up here.','muted'));};
    search.oninput=draw;const tools=node('div',null,'row');const exportButton=node('button','Export journal');exportButton.onclick=()=>{const blob=new Blob([entries.map(x=>`${x.date} · ${x.mood}\n${x.title}\n\n${x.body}`).join('\n\n---\n\n')],{type:'text/plain'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='dirazcoder-journal.txt';a.click();URL.revokeObjectURL(a.href);};tools.append(exportButton);
    draw();root.append(head,form,tools,search,list);
  };
  render();
})();
