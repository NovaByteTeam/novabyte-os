(() => {
  const key='dirazcoder.workout.v1',root=document.querySelector('#app');
  const date=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
  const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  let logs;try{logs=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(logs))logs=[];}catch{logs=[];}
  const save=()=>localStorage.setItem(key,JSON.stringify(logs));
  const render=()=>{
    root.replaceChildren();const head=node('header');head.append(node('h1','Workout Log'),node('p','Track the work. Celebrate the progress.'));
    const form=node('form',null,'panel grid');const row=node('div',null,'row');
    const exercise=node('input');exercise.placeholder='Exercise';exercise.required=true;exercise.maxLength=80;
    const sets=node('input');sets.type='number';sets.min='1';sets.max='30';sets.value='3';sets.title='Sets';
    const reps=node('input');reps.type='number';reps.min='1';reps.max='1000';reps.value='10';reps.title='Reps per set';
    const weight=node('input');weight.type='number';weight.min='0';weight.step='0.5';weight.placeholder='kg';weight.title='Weight in kg';
    const add=node('button','Log exercise','primary');add.type='submit';row.append(exercise,sets,reps,weight,add);form.append(row);
    form.onsubmit=e=>{e.preventDefault();logs.unshift({id:crypto.randomUUID(),exercise:exercise.value.trim(),sets:Number(sets.value),reps:Number(reps.value),weight:Number(weight.value)||0,date:date()});save();render();};
    const bests=new Map();for(const log of logs)bests.set(log.exercise,Math.max(bests.get(log.exercise)||0,log.weight));
    const stats=node('div',null,'stats');for(const [n,l] of [[logs.length,'logged exercises'],[new Set(logs.map(x=>x.date)).size,'training days'],[bests.size,'exercises tracked']]){const s=node('div',null,'stat');s.append(node('strong',String(n)),node('span',l));stats.append(s);}
    const list=node('section',null,'list');for(const log of logs){const item=node('article',null,'item'),copy=node('div');copy.append(node('strong',log.exercise),node('p',`${log.date} · ${log.sets} × ${log.reps} · ${log.weight} kg`,'muted'));
      if(log.weight===bests.get(log.exercise)&&log.weight>0)copy.append(node('span','Personal best','accent'));
      const remove=node('button','Delete');remove.onclick=()=>{logs=logs.filter(x=>x.id!==log.id);save();render();};item.append(copy,remove);list.append(item);}
    if(!logs.length)list.append(node('p','Log your first exercise to start building a training history.','muted'));
    root.append(head,form,stats,node('h2','Training history'),list);
  };
  render();
})();
